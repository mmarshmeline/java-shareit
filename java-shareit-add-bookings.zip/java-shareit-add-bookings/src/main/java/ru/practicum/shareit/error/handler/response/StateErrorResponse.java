package ru.practicum.shareit.error.handler.response;

import lombok.AllArgsConstructor;
import lombok.Getter;

@Getter
@AllArgsConstructor
public class StateErrorResponse {
    private String error;
}
